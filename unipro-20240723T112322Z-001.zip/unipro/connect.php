<?php
    $firstName = $_POST['firstname'];
    $lastName = $_POST['secondname'];
    $email = $_POST['email'];
    $phone = $_POST['cemail'];

    //Database connection
    $conn = new mysqli('localhost', 'root', '', 'university_db');
    if($conn->connect_error){
        die('Connection Failed : '.$conn->connect_error);
    }else{
        $stmt = $conn->prepare("insert into enroll(firstname, secondname, email, cemail) values(?, ?, ?, ?)");
        $stmt->bind_param("ssss", $firstname, $secondname, $email, $cemail);
        $stmt->execute();
        echo "Message has been sent!";
        $stmt->close();
        $conn->close();
    }
?>