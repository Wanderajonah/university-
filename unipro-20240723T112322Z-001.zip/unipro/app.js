const slides = document.querySelectorAll('.slide');
let currentSlide = 0;

function showSlide() {
  slides.forEach((slide, index) => {
    if (index === currentSlide) {
      slide.classList.add('active');
    } else {
      slide.classList.remove('active');
    }
  });
}

function nextSlide() {
  currentSlide++;
  if (currentSlide > slides.length - 1) {
    currentSlide = 0;
  }
  showSlide();
}
setInterval(nextSlide, 6000);
// ---navbar---
const navLinks = document.getElementById('navLinks');
 
function showMenu(){
  navLinks.style.right = 0;
}
function hideMenu(){
  navLinks.style.right = '-200px';
}







